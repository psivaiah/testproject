#!/bin/bash
######################
# Purpose: To learn shell script
# Version: 1.0
# Owner  : info@tejoyasha.com
# Input  : None
# Output : Message on screen
######################

