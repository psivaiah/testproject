#!/bin/bash
######################
# Purpose: To learn variables in shell scripting
# Version: 1.0
# Owner  : info@tejoyasha.com
# Input  : None
# Output : Message on screen
######################

echo "The  env variable value of AGE is $AGE"

AGE=25

echo "The script variable value of AGE is $AGE"

echo " "

echo "Please enter the AGE of your choice"

read AGE

echo "The new variable value of AGE is $AGE"



