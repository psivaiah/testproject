#!/bin/bash
######################
# Purpose: To learn variables in shell scripting
# Version: 1.0
# Owner  : info@tejoyasha.com
# Input  : None
# Output : Message on screen
######################


COMMAND=/bin/ls


# Expedted Output: The value of $COMMAND is /bin/ls

echo "The value of $COMMAND is $COMMAND"




